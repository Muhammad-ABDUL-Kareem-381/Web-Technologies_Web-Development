# Student Records Management System

A simple **C# console application** for managing student records.  
This project demonstrates the use of:
- Classes and objects in C#
- File handling (save & read student records from a text file)
- Menu-driven console interface
- Basic input validation

---

## 👨‍🎓 Student Information
- **Name:** Muhammad Abdul Kareem  
- **Roll No:** BSEF23M014  
- **Department:** BS(SE)  
- **Session:** Morning  

---

## 📂 Features
- Add a new student (Name, ID, Age, Department)
- View all stored student records
- Data is saved in a local file (`students.txt`) so it persists after program exit

---

## ▶️ How to Run
1. Clone this repository:
   ```bash
   https://github.com/web-technologies-fall-2025/homework01-PUCIT-DEV.git
