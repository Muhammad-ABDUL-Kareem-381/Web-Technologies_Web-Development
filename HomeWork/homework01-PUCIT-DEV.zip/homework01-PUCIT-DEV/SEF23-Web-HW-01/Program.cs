﻿using System;
using Student_Records_CDM;

namespace Student_Records
{
    class MainClass
    {
        static void Main()
        {
            StudentCDM studentCDM = new StudentCDM();
            Console.WriteLine("\t\t\tStudent Records Management System");
            int choice = 0;
            do // Menu loop
            {
                Console.WriteLine("1. Add Student");
                Console.WriteLine("2. View Students");
                Console.WriteLine("3. Exit");
                Console.Write("Enter your choice: ");
                string? temp = Console.ReadLine();
                if (!string.IsNullOrEmpty(temp) && int.TryParse(temp, out choice))
                {
                        choice = int.Parse(temp);
                }
                else // Handle invalid input
                {
                    Console.WriteLine("Invalid input.");
                    choice = 4;
                }
                if (choice == 1) // Add student
                {
                    studentCDM.AddStudent(); // Add student details
                }
                else if (choice == 2) // View students
                {
                    studentCDM.displayStudentRecord(); // Display student records
                }
                else if (choice ==3) // Exit
                {
                    Console.WriteLine("\nExiting...");
                }
                else // Invalid choice
                {
                    Console.WriteLine("\nInvalid choice. Please try again.\n");
                }
            }
            while (choice != 3); // Continue until user chooses to exit

        }

    }
}


