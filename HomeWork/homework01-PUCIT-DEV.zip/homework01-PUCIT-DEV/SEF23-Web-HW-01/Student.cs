﻿using System;

namespace Student_Records
{
    internal class Student
    {
        // Fields
        private string name; // Student's name
        private int id; // Student's ID
        private int age; // Student's age
        private string department; // Student's department

        // Constructors
        public Student() // Default constructor
        {
            name = "Unknown";
            id = 0;
            age = 0;
            department = "Undeclared";
        }
        public Student(string name, int id, int age, string department) // Parameterized constructor
        {
            this.name = name;
            this.id = id;
            this.age = age;
            this.department = department;
        }

        // Properties
        public string Name // Property for Name
        {
            get { return name; }
            set { name = value; }
        }
        public int Id // Property for Id
        {
            get { return id; }
            set { id = value; }
        }
        public int Age // Property for Age
        {
            get { return age; }
            set { age = value; }
        }
        public string Department // Property for Department
        {
            get { return department; }
            set { department = value; }
        }

        // Functions
        public override string ToString() // ToString() override for neat printing
        {
            return $"{id}, {name}, {age}, {department}";
        }

    }
}

