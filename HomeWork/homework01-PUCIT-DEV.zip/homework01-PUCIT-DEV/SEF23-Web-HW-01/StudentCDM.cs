﻿using Student_Records_DAL;
using Student_Records;
using System;

namespace Student_Records_CDM
{
    internal class StudentCDM
    {
        // Constructor
        public StudentCDM() // Default constructor
        {

        }

        // Functions
        public void AddStudent() // Function to add student details
        {
            Console.Write("Enter Student Name: ");
            string? sName = Console.ReadLine();
            while (string.IsNullOrEmpty(sName))
            {
                Console.Write("Name cannot be empty. Please enter Student Name: ");
                sName = Console.ReadLine();
            }
            Console.Write("Enter Student ID: ");
            string? sId = Console.ReadLine();
            int id;
            while (string.IsNullOrEmpty(sId) || !int.TryParse(sId,out id))
            {
                Console.Write("Invalid input. Please enter a valid Student ID: ");
                sId = Console.ReadLine();
            }
            id = int.Parse(sId);
            Console.Write("Enter Student Age: ");
            string? sAge = Console.ReadLine();
            int age;
            while (string.IsNullOrEmpty(sAge) || !int.TryParse(sAge,out age)) // Check for empty input
            {
                Console.Write("Invalid input. Please enter a valid Student Age: ");
                sAge = Console.ReadLine();
            }
            age = int.Parse(sAge);
            Console.Write("Enter Student Department: ");
            string? sDept = Console.ReadLine();
            while (string.IsNullOrEmpty(sDept)) // Check for empty input
            {
                Console.Write("Department cannot be empty. Please enter Student Department: ");
                sDept = Console.ReadLine();
            }
            Student student = new Student(sName, id, age, sDept);
            StudentDAL studentDAL = new StudentDAL();
            studentDAL.AddStudentRecord(student);
        }

        public void displayStudentRecord() // Function to display student records
        {
            StudentDAL studentDAL = new StudentDAL();
            string? studentRecord = studentDAL.GetStudentsRecords();
            if (string.IsNullOrEmpty(studentRecord)) // If no records found, return
            {
                return;
            }
            else // If records found, display them
            {
                int count = 1;
                int fieldCount = 1;
                for (int i = 0; i < studentRecord.Length; i++) // Read each character from the string
                {
                    char currentChar = studentRecord[i];
                    if (currentChar == ',' && fieldCount == 1) // Check for field separators and print accordingly
                    {
                        Console.WriteLine($"\n\t\tStudent Record no: {count}\n");
                        Console.WriteLine($"Id: {(studentRecord.Substring(0, i)).Trim()}");
                        count++;
                        fieldCount++;
                        studentRecord = studentRecord.Substring(i + 1);
                        i = -1; // Reset index for new substring
                    }
                    else if (currentChar == ',' && fieldCount == 2) // Check for field separators and print accordingly
                    {
                        Console.WriteLine($"Name: {(studentRecord.Substring(0, i)).Trim()}");
                        fieldCount++;
                        studentRecord = studentRecord.Substring(i + 1);
                        i = -1; // Reset index for new substring
                    }
                    else if (currentChar == ',' && fieldCount == 3) // Check for field separators and print accordingly
                    {
                        Console.WriteLine($"Age: {(studentRecord.Substring(0, i)).Trim()}");
                        fieldCount++;
                        studentRecord = studentRecord.Substring(i + 1);
                        i = -1; // Reset index for new substring
                    }
                    else if (currentChar == '\n' && fieldCount == 4) // Check for field separators and print accordingly
                    {
                        Console.WriteLine($"Department: {(studentRecord.Substring(0, i)).Trim()}");
                        fieldCount = 1;
                        studentRecord = studentRecord.Substring(i + 1);
                        i = -1; // Reset index for new substring
                    }
                }
                Console.WriteLine($"\n <-----------------Record has ended----------------> \n" ); // Indicate end of records
            }
        }
    }
}
