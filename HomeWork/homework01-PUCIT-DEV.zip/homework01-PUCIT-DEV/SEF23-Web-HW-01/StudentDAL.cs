﻿using System;
using System.IO;
using Student_Records;

namespace Student_Records_DAL
{
    internal class StudentDAL
    {
        // Constructor
        public StudentDAL() 
        {
        
        }

        //Functions
        public void AddStudentRecord(Student student) // Function to add student record to file
        {
            FileStream studentRecord = new FileStream("students.txt", FileMode.Append);
            string? temp = student.ToString();
            if (string.IsNullOrEmpty(temp)) // Check if student data is empty
            {
                Console.WriteLine("\n\t\t\tError: Student data is empty.");
            }
            else // Write student data to file
            {
                for (int i = 0; i < temp.Length; i++) // Write each character to file
                {
                    studentRecord.WriteByte((byte)temp[i]);
                }
                studentRecord.WriteByte((byte)'\n');
                Console.WriteLine("\nStudent added successfully.\n");

            }
            studentRecord.Close();
        }

        public string? GetStudentsRecords() // Function to get student records from file
        {
            string? temp = null;
            char? tChar = null;
            if (!File.Exists("students.txt")) // Check if file exists
            {
                Console.WriteLine("\nStudent Records does not exist.\n");
            }
            FileStream studentRecord = new FileStream("students.txt", FileMode.Open);
            if (studentRecord.Length == 0) // Check if file is empty
            {
                Console.WriteLine("\nNo student records found.\n");
                studentRecord.Close();
            }
            else // Read student data from file
            {
                while (studentRecord.Position < studentRecord.Length) // Read until end of file
                {
                    tChar = (char)studentRecord.ReadByte(); // Read next character
                    temp += tChar; // Read each character
                }
                studentRecord.Close();
            }
            return temp; // Return student data as string
        }
    }
}
